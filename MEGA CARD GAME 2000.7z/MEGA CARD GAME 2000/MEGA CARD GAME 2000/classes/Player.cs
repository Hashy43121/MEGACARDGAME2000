﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MEGA_CARD_GAME_2000.classes
{
    class Player : Character
    {
        public Char characterName;
        public Attack currentAttack;
        public PlayerClass playerClass;

        public bool NormalAttack()
        {
            return true;
        }

        public Player(char pcharacterName, int pbaseDamage, int pcurrentHealthPoints, int pmaxHealthPoints) : base(pbaseDamage, pcurrentHealthPoints, pmaxHealthPoints)
        {
            characterName = pcharacterName;
            baseDamage = pbaseDamage;
            currentHealthPoints = pcurrentHealthPoints;
            maxHealthPoints = pmaxHealthPoints;
        }

        public Player(char pcharacterName)
        {
            return Player;
        }

        public int PlayerHealth()
        {
            return currentHealthPoints - baseDamage;
        }

        // The attack type isn't created 
        public bool SpecialAttack(attackType SpecializedAttack)
        {
            return true;
        }

        public char GetcharacterName(char characterName)
        {
            return characterName;
        }

        public Attack GetcurrentAttack(Attack currentAttack)
        {
            return currentAttack;
        }

        public PlayerClass GetplayerClass()
        {
            return playerClass;
        }

        public void SetcharacterName(char newVal)
        {
            characterName = newVal;
        }

        public void SetcurrentAttack(Attack newVal)
        {
            currentAttack = newVal;
        }

        public void SetplayerClass(PlayerClass newVal)
        {
            playerClass = newVal;
        }
    }
}


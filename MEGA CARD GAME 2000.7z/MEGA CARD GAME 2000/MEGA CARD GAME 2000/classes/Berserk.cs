﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MEGA_CARD_GAME_2000.classes
{
    class Berserk : SpecializedAttack
    {
        successAttemptDamage = 3;
        failedAttemptDamage = 0;
        successRate = 0.33;
        attackName = Berserk;
    }
}

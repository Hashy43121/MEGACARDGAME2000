﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MEGA_CARD_GAME_2000.classes
{
    class Fireball
    {
        successAttemptDamage = -1;
       failedAttemptDamage = 4;
       successRate = 0.5;
       attackName = Fireball;
    }
}

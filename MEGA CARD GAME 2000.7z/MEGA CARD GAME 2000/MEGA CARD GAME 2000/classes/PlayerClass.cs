﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MEGA_CARD_GAME_2000.classes
{
    class PlayerClass
    {
        public SpecializedAttack attack;

        public SpecializedAttack Getattack()
        {
            return SpecializedAttack;
        }

        public void Setattack(SpecializedAttack newVal)
        {
            SpecializedAttack = newVal;
        }
    }
}

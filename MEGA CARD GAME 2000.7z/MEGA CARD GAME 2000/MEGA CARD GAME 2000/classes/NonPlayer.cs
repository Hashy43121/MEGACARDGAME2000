﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MEGA_CARD_GAME_2000.classes
{
    class NonPlayer : Character
    {
        public NormalAttack attack;

        public NonPlayer(int pBaseDamage, int pCurrentHealthPoints, int pMaxHealthPoints) : base(pBaseDamage, pCurrentHealthPoints, pMaxHealthPoints)
        {
            baseDamage = pBaseDamage;
            currentHealthPoints = pCurrentHealthPoints;
            maxHealthPoints = pMaxHealthPoints;
        }

        public int NonPlayerHealth()
        {
            return currentHealthPoints - baseDamage;
        }

        public bool NormalAttack()
        {
            return true;
        }
    }
}

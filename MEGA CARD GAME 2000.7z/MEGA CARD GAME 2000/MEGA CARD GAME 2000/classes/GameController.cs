﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MEGA_CARD_GAME_2000.classes
{
    class GameController
    {
        public NonPlayer enemy;
        public Player player;
        private NonPlayer nonPlayer;
        private Player getPlayer;

        public int NonPlayerHealth { get;  set; }
        public int PlayerHealth { get;  set; }

        public int CheckEnemyHealth()
        {
            return NonPlayerHealth = 0;
        }

        public int CheckPlayerHealth()
        {
            return PlayerHealth = 0;
        }

        public void ChoosePlayerClass(PlayerClass);

        public DetermineFirstTurn()
        {
            return Character;
        }

        public bool EndGame()
        {
            return true;
        }

        public void EnemyTurn();

        public void PlayerTurn();

        public SelectEnemy()
        {
            return NonPlayer;
        }

        public SetPlayerAttack(char playerSelection)
        {
            return Attack;
        }

        public void StartBattle();

        public void StartGame();

        public NonPlayer GetEnemy()
        {
            return nonPlayer;
        }

        public Player GetPlayer()
        {
            return getPlayer;
        }

        public void Setenemy(NonPlayer newVal)
        {
            SetEnemy = newVal;
        }

        public void Setplayer(Player newVal)
        {
            Setplayer = newVal;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MEGA_CARD_GAME_2000.classes
{
    class SpecializedAttack : Attack
    {
        public char attackName;
        public double failedAttemptDamage;
        public double successAttemptDamage;
        public double successRate;

        public SpecializedAttack(char attackName)
        {
            return SpecializedAttack;
        }

        public char GetattackName(char attackName)
        {
            return attackName;
        }

        public double GetfailedAttemptDamage(double failedAttemptDamage)
        {
            return failedAttemptDamage;
        }

        public double GetsuccessAttemptDamage(double successAttemptDamage)
        {
            return successAttemptDamage;
        }

        public double GetsuccessRate(double successRate)
        {
            return successRate;
        }

        public void SetattackName(char newVal)
        {
            attackName = newVal;
        }

        public void SetfailedAttemptDamage(double newVal)
        {
            failedAttemptDamage = newVal;
        }

        public void SetsuccessAttemptDamage(double newVal)
        {
            successAttemptDamage = newVal;
        }

        public void SetsuccessRate(double newVal)
        {
            successRate = newVal;
        }
    }
}

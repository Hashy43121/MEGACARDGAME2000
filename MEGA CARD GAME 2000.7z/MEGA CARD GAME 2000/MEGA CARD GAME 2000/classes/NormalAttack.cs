﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MEGA_CARD_GAME_2000.classes
{
    class NormalAttack : Attack
    {

        public int AttackEnemy(Player player)
        {
            return baseDamage;
        }

        public int AttackEnemy(NonPlayer nonPlayer)
        {
            return baseDamage;
        }
    }
}

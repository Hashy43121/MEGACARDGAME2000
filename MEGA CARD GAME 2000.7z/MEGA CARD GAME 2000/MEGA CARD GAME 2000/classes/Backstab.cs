﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MEGA_CARD_GAME_2000.classes
{
    class Backstab : SpecializedAttack
    {
       successAttemptDamage = 0.5;
       failedAttemptDamage = 2;
       successRate = 0.33;
       attackName = Backstab;
    }
}

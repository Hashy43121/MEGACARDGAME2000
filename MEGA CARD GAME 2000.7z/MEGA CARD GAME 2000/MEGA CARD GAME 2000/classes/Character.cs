﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MEGA_CARD_GAME_2000.classes
{
    class Character
    {
       public int baseDamage;
       public int currentHealthPoints;
       public int maxHealthPoints;

        public int CalculateHealthPoints(int damagePoints)
        {
            return currentHealthPoints - damagePoints;
        }


        public Character(int pBaseDamage, int pCurrentHealthPoints, int pMaxHealthPoints)
        {
            baseDamage = pBaseDamage;
            currentHealthPoints = pCurrentHealthPoints;
            maxHealthPoints = pMaxHealthPoints;
        }

        public int GetbaseDamage(int baseDamage)
        {
            return baseDamage;
        }

        public int GetcurrentHealthPoints()
        {
            return currentHealthPoints;
        }

        public int GetmaxHealthPoints()
        {
            return maxHealthPoints;
        }

        public void SetbaseDamage(int newVal)
        {
            baseDamage = newVal;
        }

        public void SetcurrentHealth(int newVal)
        {
            currentHealthPoints = newVal;
        }

        public void SetmaxHealthPoints(int newVal)
        {
            maxHealthPoints = newVal;
        }
    }
}
